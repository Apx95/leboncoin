<!-- filepath: c:\xamp\htdocs\leboncoin-main (2)\leboncoin-main\edit_profile.php -->
<?php
session_start();
require 'db.php';

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Récupérer les informations de l'utilisateur connecté
$user_id = $_SESSION['user_id'];
$stmt = $db->prepare("SELECT pseudo, email, telephone, localisation FROM utilisateurs WHERE utilisateur_id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pseudo = trim($_POST['pseudo']);
    $email = trim($_POST['email']);
    $telephone = trim($_POST['telephone']);
    $localisation = trim($_POST['localisation']);

    try {
        $stmt = $db->prepare("UPDATE utilisateurs SET pseudo = ?, email = ?, telephone = ?, localisation = ? WHERE utilisateur_id = ?");
        $stmt->execute([$pseudo, $email, $telephone, $localisation, $user_id]);
        $_SESSION['success'] = "Profil mis à jour avec succès.";
        header("Location: profile_info.php");
        exit();
    } catch (PDOException $e) {
        $error = "Une erreur est survenue lors de la mise à jour.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier le profil - ElectroBazar</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            background-color: #F4F6F8;
            font-family: 'Roboto', sans-serif;
        }
        .profile-edit-container {
            max-width: 600px;
            margin: 50px auto;
            background-color: #FFFFFF;
            border: 1px solid #E0E0E0;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }
        .profile-edit-container h3 {
            font-weight: bold;
            margin-bottom: 20px;
        }
        .profile-edit-container .form-group {
            margin-bottom: 15px;
        }
        .profile-edit-container .form-control {
            border-radius: 5px;
        }
        .profile-edit-container .btn-primary {
            background-color: #007BFF;
            border: none;
            border-radius: 5px;
        }
        .profile-edit-container .btn-primary:hover {
            background-color: #0056b3;
        }
        .profile-icon {
            font-size: 5rem;
            color: #007BFF;
            display: block;
            margin: 0 auto 20px;
        }
    </style>
</head>
<body>
    <div class="profile-edit-container">
        <i class="bi bi-person-circle profile-icon"></i>
        <h3 class="text-center">Modifier le profil</h3>
        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <form action="edit_profile.php" method="POST">
            <div class="form-group">
                <label for="pseudo">Pseudo</label>
                <input type="text" class="form-control" id="pseudo" name="pseudo" value="<?= htmlspecialchars($user['pseudo']) ?>" required>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" class="form-control" id="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required>
            </div>
            <div class="form-group">
                <label for="telephone">Téléphone</label>
                <input type="text" class="form-control" id="telephone" name="telephone" value="<?= htmlspecialchars($user['telephone']) ?>" required>
            </div>
            <div class="form-group">
                <label for="localisation">Localisation</label>
                <input type="text" class="form-control" id="localisation" name="localisation" value="<?= htmlspecialchars($user['localisation']) ?>" required>
            </div>
            <button type="submit" class="btn btn-primary w-100">Enregistrer</button>
        </form>
    </div>
</body>
</html>