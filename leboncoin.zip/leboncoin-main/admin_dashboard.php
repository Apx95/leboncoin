<?php
session_start();
require 'db.php';

// Vérification si l'utilisateur est un administrateur
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: login.php');
    exit;
}

// Récupération des annonces et des utilisateurs
try {
    $stmt = $db->query("SELECT * FROM annonces ORDER BY date_creation DESC");
    $annonces = $stmt->fetchAll();

    $stmt = $db->query("SELECT * FROM utilisateurs ORDER BY date_creation DESC");
    $utilisateurs = $stmt->fetchAll();
} catch (PDOException $e) {
    die("Erreur : " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de bord Admin - ElectroBazar</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        .admin-header {
            background-color: #007BFF;
            color: white;
            padding: 20px;
            text-align: center;
        }
        .admin-header h1 {
            font-size: 2.5rem;
        }
        .table-actions button {
            margin-right: 5px;
        }
    </style>
</head>
<body>
    <div class="admin-header">
        <h1>Tableau de bord Administrateur</h1>
        <a href="accueil.php" class="btn btn-light">Retour au site</a>
    </div>

    <div class="container mt-4">
        <h2>Gestion des Annonces</h2>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Titre</th>
                    <th>Prix</th>
                    <th>Utilisateur</th>
                    <th>Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($annonces as $annonce): ?>
                    <tr>
                        <td><?= $annonce['annonce_id'] ?></td>
                        <td><?= htmlspecialchars($annonce['titre']) ?></td>
                        <td><?= number_format($annonce['prix'], 2, ',', ' ') ?> €</td>
                        <td><?= htmlspecialchars($annonce['utilisateur_id']) ?></td>
                        <td><?= $annonce['date_creation'] ?></td>
                        <td class="table-actions">
                            <button class="btn btn-primary btn-sm" onclick="modifierAnnonce(<?= $annonce['annonce_id'] ?>)">
                                <i class="bi bi-pencil"></i> Modifier
                            </button>
                            <button class="btn btn-danger btn-sm" onclick="supprimerAnnonce(<?= $annonce['annonce_id'] ?>)">
                                <i class="bi bi-trash"></i> Supprimer
                            </button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <h2>Gestion des Utilisateurs</h2>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Pseudo</th>
                    <th>Email</th>
                    <th>Date d'inscription</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($utilisateurs as $utilisateur): ?>
                    <tr>
                        <td><?= $utilisateur['utilisateur_id'] ?></td>
                        <td><?= htmlspecialchars($utilisateur['pseudo']) ?></td>
                        <td><?= htmlspecialchars($utilisateur['email']) ?></td>
                        <td><?= $utilisateur['date_creation'] ?></td>
                        <td class="table-actions">
                            <button class="btn btn-primary btn-sm" onclick="modifierUtilisateur(<?= $utilisateur['utilisateur_id'] ?>)">
                                <i class="bi bi-pencil"></i> Modifier
                            </button>
                            <button class="btn btn-danger btn-sm" onclick="supprimerUtilisateur(<?= $utilisateur['utilisateur_id'] ?>)">
                                <i class="bi bi-trash"></i> Supprimer
                            </button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <script>
        function modifierAnnonce(id) {
            window.location.href = `edit_annonce.php?id=${id}`;
        }

        function supprimerAnnonce(id) {
            if (confirm('Êtes-vous sûr de vouloir supprimer cette annonce ?')) {
                fetch('supp_annonce.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ annonce_id: id })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('Annonce supprimée avec succès');
                        location.reload();
                    } else {
                        alert('Erreur : ' + data.error);
                    }
                });
            }
        }

        function modifierUtilisateur(id) {
            window.location.href = `edit_utilisateur.php?id=${id}`;
        }

        function supprimerUtilisateur(id) {
            if (confirm('Êtes-vous sûr de vouloir supprimer cet utilisateur ?')) {
                fetch('supp_utilisateur.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ utilisateur_id: id })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('Utilisateur supprimé avec succès');
                        location.reload();
                    } else {
                        alert('Erreur : ' + data.error);
                    }
                });
            }
        }
    </script>
</body>
</html>