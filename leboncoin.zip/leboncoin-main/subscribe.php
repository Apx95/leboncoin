<?php
session_start();
require 'db.php';

header('Content-Type: application/json');

// Vérification de l'authentification
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Non autorisé']);
    exit;
}

// Récupération des données JSON
$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['vendeur_id']) || !is_numeric($data['vendeur_id'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'ID du vendeur invalide']);
    exit;
}

$abonne_id = $_SESSION['user_id'];
$vendeur_id = intval($data['vendeur_id']);

if ($abonne_id === $vendeur_id) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Vous ne pouvez pas vous abonner à vous-même']);
    exit;
}

try {
    // Vérifier si l'utilisateur est déjà abonné
    $stmt = $db->prepare("SELECT * FROM abonnements WHERE abonne_id = ? AND vendeur_id = ?");
    $stmt->execute([$abonne_id, $vendeur_id]);
    $abonnement = $stmt->fetch();

    if ($abonnement) {
        // Désabonnement
        $stmt = $db->prepare("DELETE FROM abonnements WHERE abonne_id = ? AND vendeur_id = ?");
        $stmt->execute([$abonne_id, $vendeur_id]);
        echo json_encode(['success' => true, 'message' => 'Désabonné avec succès']);
    } else {
        // Abonnement
        $stmt = $db->prepare("INSERT INTO abonnements (abonne_id, vendeur_id) VALUES (?, ?)");
        $stmt->execute([$abonne_id, $vendeur_id]);
        echo json_encode(['success' => true, 'message' => 'Abonné avec succès']);
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Erreur serveur : ' . $e->getMessage()]);
}