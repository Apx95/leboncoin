<?php
session_start();
require 'db.php';

header('Content-Type: application/json');

// Vérification de l'authentification et des droits d'administration
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Accès non autorisé']);
    exit;
}

// Récupération et validation des données
$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['utilisateur_id']) || !is_numeric($data['utilisateur_id'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'ID utilisateur invalide']);
    exit;
}

try {
    $stmt = $db->prepare("DELETE FROM utilisateurs WHERE utilisateur_id = ?");
    $stmt->execute([$data['utilisateur_id']]);

    echo json_encode(['success' => true]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}