<!-- filepath: c:\xampp\htdocs\leboncoin\index.php -->
<!-- filepath: c:\xamp\htdocs\leboncoin-main (2)\leboncoin-main\index.php -->
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ElectroBazar - Accueil</title>
    <link rel="stylesheet" href="styles.css"> <!-- Fichier CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"> <!-- Bootstrap -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css"> <!-- Bootstrap Icons -->
    <style>
        /* Ajustement de la navbar */
        .navbar .form-control {
            width: 300px;
            transition: width 0.3s ease-in-out;
        }
        .navbar .form-control:focus {
            width: 400px;
        }
        .btn-deposer {
            margin-left: 20px;
            padding: 10px 20px;
            font-size: 1rem;
        }
    </style>
</head>
<body>
    <!-- Inclusion de la navbar -->
    <?php include 'navbarCo.php'; ?>

    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar des catégories -->
            <aside class="col-lg-3 col-md-4 sidebar">
                <h3 class="sidebar-title">Catégories</h3>
                <ul class="list-group">
                    <?php
                    try {
                        require_once 'db.php';
                        $stmt = $db->query("
                            SELECT c.categorie_id, c.nom, c.icone,
                                   COUNT(a.annonce_id) as nb_annonces
                            FROM categories c
                            LEFT JOIN annonces a ON a.categorie_id = c.categorie_id
                            WHERE c.categorie_parent_id IS NULL
                            GROUP BY c.categorie_id
                            ORDER BY c.nom
                        ");
                        $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    
                        foreach ($categories as $categorie) {
                            $icon = $categorie['icone'] ?? 'grid';
                            $nbAnnonces = $categorie['nb_annonces'] > 0 ? 
                                "<span class='badge bg-primary float-end'>{$categorie['nb_annonces']}</span>" : '';
                            
                            echo "<li class='list-group-item'>";
                            echo "<a href='category.php?id={$categorie['categorie_id']}' 
                                     class='d-flex justify-content-between align-items-center text-decoration-none'>";
                            echo "<span><i class='bi bi-{$icon} me-2'></i>" . 
                                 htmlspecialchars($categorie['nom']) . "</span>";
                            echo $nbAnnonces;
                            echo "</a></li>";
                        }
                    } catch(PDOException $e) {
                        echo "<li class='list-group-item text-danger'>Erreur de chargement des catégories</li>";
                    }
                    ?>
                </ul>
            </aside>

            <!-- Contenu principal -->
            <main class="col-lg-9 col-md-8">
                <!-- Bannière centrale -->
                <section class="banner text-center">
                    <h2>Bienvenue sur ElectroBazar</h2>
                    <p>Trouvez votre prochain appareil électronique au meilleur prix !</p>
                    <a href="Depot_annonce.php" class="btn btn-banner">Publier une annonce</a>
                </section>

                <!-- Section Tendance -->
                <section class="trending">
                    <h2 class="section-title">Annonces récentes</h2>
                    <div class="row g-4">
                        <?php
                        try {
                            $stmt = $db->query("
                                SELECT a.*, 
                                       u.pseudo, 
                                       GROUP_CONCAT(DISTINCT i.url) as images,
                                       c.nom as categorie_nom,
                                       m.nom as marque_nom
                                FROM annonces a
                                LEFT JOIN utilisateurs u ON a.utilisateur_id = u.utilisateur_id
                                LEFT JOIN images i ON a.annonce_id = i.annonce_id
                                LEFT JOIN categories c ON a.categorie_id = c.categorie_id
                                LEFT JOIN marques m ON a.marque_id = m.id
                                WHERE a.statut = 'active'
                                GROUP BY a.annonce_id
                                ORDER BY a.date_creation DESC
                                LIMIT 12
                            ");
                            $annonces = $stmt->fetchAll(PDO::FETCH_ASSOC);

                            foreach ($annonces as $annonce) {
                                $images = explode(',', $annonce['images']);
                                $premiere_image = !empty($images[0]) ? 'uploads/' . $images[0] : 'images/default.jpg';
                                echo "
                                <div class='col-md-4'>
                                    <div class='card'>
                                        <img src='{$premiere_image}' class='card-img-top' alt='" . htmlspecialchars($annonce['titre']) . "' style='height: 200px; object-fit: cover;'>
                                        <div class='card-body'>
                                            <h5 class='card-title'>" . htmlspecialchars($annonce['titre']) . "</h5>
                                            <p class='card-text'>Prix : " . number_format($annonce['prix'], 2, ',', ' ') . " €</p>
                                            <a href='voir_annonce.php?id={$annonce['annonce_id']}' class='btn btn-primary'>Voir l'annonce</a>
                                        </div>
                                    </div>
                                </div>";
                            }
                        } catch(PDOException $e) {
                            echo "<div class='alert alert-danger'>Erreur : " . $e->getMessage() . "</div>";
                        }
                        ?>
                    </div>
                </section>
            </main>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer text-center">
        <p>&copy; 2025 ElectroBazar. Tous droits réservés.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>