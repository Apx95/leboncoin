<?php
session_start();
require 'db.php';

header('Content-Type: application/json');

// Vérification de l'authentification et des droits d'administration
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Accès refusé']);
    exit;
}

// Récupération et validation des données
$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['annonce_id']) || !is_numeric($data['annonce_id'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'ID de l\'annonce invalide']);
    exit;
}

$annonce_id = intval($data['annonce_id']);

try {
    // Suppression de l'annonce
    $stmt = $db->prepare("DELETE FROM annonces WHERE annonce_id = ?");
    $stmt->execute([$annonce_id]);

    if ($stmt->rowCount() > 0) {
        echo json_encode(['success' => true, 'message' => 'Annonce supprimée avec succès']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Aucune annonce trouvée avec cet ID']);
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Erreur serveur : ' . $e->getMessage()]);
}