<?php
session_start();
require 'db.php';

// Vérification de l'authentification
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$abonne_id = $_SESSION['user_id'];

try {
    // Récupérer les abonnements
    $stmt = $db->prepare("
        SELECT u.utilisateur_id, u.pseudo, u.email, u.telephone 
        FROM abonnements a
        JOIN utilisateurs u ON a.vendeur_id = u.utilisateur_id
        WHERE a.abonne_id = ?
    ");
    $stmt->execute([$abonne_id]);
    $abonnements = $stmt->fetchAll();

    // Récupérer les abonnés
    $stmt = $db->prepare("
        SELECT u.utilisateur_id, u.pseudo, u.email, u.telephone 
        FROM abonnements a
        JOIN utilisateurs u ON a.abonne_id = u.utilisateur_id
        WHERE a.vendeur_id = ?
    ");
    $stmt->execute([$abonne_id]);
    $abonnes = $stmt->fetchAll();
} catch (PDOException $e) {
    die("Erreur : " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mes abonnements et abonnés - ElectroBazar</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <style>
        body {
            background-color: #F4F6F8;
            font-family: 'Roboto', sans-serif;
        }
        .container {
            margin-top: 50px;
        }
        .list-group-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .list-group-item strong {
            font-size: 1.2rem;
        }
        .btn-unsubscribe {
            background-color: #dc3545;
            color: #fff;
            border: none;
            padding: 5px 10px;
            border-radius: 5px;
            font-size: 0.9rem;
        }
        .btn-unsubscribe:hover {
            background-color: #c82333;
        }
    </style>
</head>
<body>
    <?php include 'navbarCo.php'; ?>

    <div class="container">
        <h3 class="mb-4">Mes abonnements et abonnés</h3>

        <!-- Onglets -->
        <ul class="nav nav-tabs mb-4" id="myTab" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="abonnements-tab" data-bs-toggle="tab" data-bs-target="#abonnements" type="button" role="tab">
                    Abonnements (<?= count($abonnements) ?>)
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="abonnes-tab" data-bs-toggle="tab" data-bs-target="#abonnes" type="button" role="tab">
                    Abonnés (<?= count($abonnes) ?>)
                </button>
            </li>
        </ul>

        <div class="tab-content" id="myTabContent">
            <!-- Abonnements -->
            <div class="tab-pane fade show active" id="abonnements" role="tabpanel" aria-labelledby="abonnements-tab">
                <?php if (count($abonnements) > 0): ?>
                    <ul class="list-group">
                        <?php foreach ($abonnements as $abonnement): ?>
                            <li class="list-group-item">
                                <div class="d-flex align-items-center">
                                    <i class="bi bi-person-circle me-2" style="font-size: 2rem; cursor: pointer;" 
                                       data-bs-toggle="modal" data-bs-target="#vendeurModal-<?= $abonnement['utilisateur_id'] ?>"></i>
                                    <strong><?= htmlspecialchars($abonnement['pseudo']) ?></strong>
                                </div>
                                <button class="btn-unsubscribe" data-vendeur-id="<?= $abonnement['utilisateur_id'] ?>">
                                    <i class="bi bi-person-dash"></i> Se désabonner
                                </button>
                            </li>

                            <!-- Modal pour afficher les informations du vendeur -->
                            <div class="modal fade" id="vendeurModal-<?= $abonnement['utilisateur_id'] ?>" tabindex="-1" aria-labelledby="vendeurModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="vendeurModalLabel">Profil du vendeur</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <p><strong>Nom :</strong> <?= htmlspecialchars($abonnement['pseudo']) ?></p>
                                            <p><strong>Email :</strong> <?= htmlspecialchars($abonnement['email'] ?? 'Non disponible') ?></p>
                                            <p><strong>Téléphone :</strong> <?= htmlspecialchars($abonnement['telephone'] ?? 'Non disponible') ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </ul>
                <?php else: ?>
                    <div class="alert alert-info">Vous n'êtes abonné à aucun vendeur pour le moment.</div>
                <?php endif; ?>
            </div>

            <!-- Abonnés -->
            <div class="tab-pane fade" id="abonnes" role="tabpanel" aria-labelledby="abonnes-tab">
                <?php if (count($abonnes) > 0): ?>
                    <ul class="list-group">
                        <?php foreach ($abonnes as $abonne): ?>
                            <li class="list-group-item">
                                <div class="d-flex align-items-center">
                                    <i class="bi bi-person-circle me-2" style="font-size: 2rem;"></i>
                                    <strong><?= htmlspecialchars($abonne['pseudo']) ?></strong>
                                </div>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php else: ?>
                    <div class="alert alert-info">Vous n'avez aucun abonné pour le moment.</div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
        document.querySelectorAll('.btn-unsubscribe').forEach(button => {
            button.addEventListener('click', function () {
                const vendeurId = this.dataset.vendeurId;
                fetch('subscribe.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ vendeur_id: vendeurId })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        this.closest('.list-group-item').remove();
                        if (document.querySelectorAll('#abonnements .list-group-item').length === 0) {
                            document.querySelector('#abonnements').innerHTML = '<div class="alert alert-info">Vous n\'êtes abonné à aucun vendeur pour le moment.</div>';
                        }
                    } else {
                        alert(data.message);
                    }
                })
                .catch(error => console.error('Erreur:', error));
            });
        });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>