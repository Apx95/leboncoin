INSERT INTO messages (message_id, sender_id, receiver_id, ad_id, content, timestamp) VALUES
(1, 1, 2, 1, 'Is this item still available?', '2023-10-01 10:00:00'),
(2, 2, 1, 1, 'Yes, it is! Would you like to come see it?', '2023-10-01 10:05:00'),
(3, 1, 3, 2, 'Can you lower the price?', '2023-10-02 11:00:00'),
(4, 3, 1, 2, 'Sorry, the price is firm.', '2023-10-02 11:10:00'),
(5, 2, 3, 3, 'What is the condition of the item?', '2023-10-03 12:00:00'),
(6, 3, 2, 3, 'It is in excellent condition, like new!', '2023-10-03 12:15:00');